 <div class="content-wrapper">
          <div class="row">
             
  <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                     <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                  <center><h4 class="card-title">Change Password</h4></center>
                 
        
                  <form class="form-horizontal" role="form"  method="post" action="<?php echo base_url() ?>ProfileSettings/update_password">
                    <div class="form-group">
                      <label for="exampleInputName1">Old Password<span style="color: red">*</span></label>
                     
                      <input type="password" class="form-control"  name="old_password" placeholder="Current Password"  required="required" />
                    </div>
                    <div class="form-group">
                      <label for="exampleInputName1">New Password<span style="color: red">*</span></label>
                     
                      <input type="password" class="form-control"  name="new_password" placeholder="New Password" required="required" />
                    </div>
                     <div class="form-group">
                      <label for="exampleInputName1">Re-enter New Password<span style="color: red">*</span></label>
                     
                      <input type="password" class="form-control"  name="renew_password" placeholder="Re-Enter New Password"  required="required" />
                    </div>
                    <button type="submit" class="btn btn-success mr-2" >Update</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
          </div>

