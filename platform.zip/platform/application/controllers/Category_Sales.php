<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_Sales extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Category_Sales_Model');
	 		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	 	}


	public function index()
	{

		$data['category_sales']=$this->Category_Sales_Model->get_all_category_sales();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('category_sales',$data);
		$this->load->view('footer');
	}
	public function category_sale_add()
		{
			$created_date  = $this->input->post('created_date');
			$scategory = $this->input->post('scategory');
					
		
			$this->form_validation->set_rules('scategory','Sales Category', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			echo json_encode(array("status" => TRUE));
		}
		else {
			$data = array(
					'created_date' => $this->input->post('created_date'),
					'scategory' => $this->input->post('scategory'),
					
					
				);
				$insert = $this->Category_Sales_Model->category_sale_add($data);
			
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Category Added Successfully'.'</div>');
				echo json_encode(array("status" => TRUE));
			
		}
			
		}
		public function ajax_category_saleedit($id)
		{
			$data = $this->Category_Sales_Model->get_by_id($id);
			echo json_encode($data);
		}

		public function category_sale_update()
	{
			$created_date  = $this->input->post('created_date');
			$scategory = $this->input->post('scategory');
			
		
			$this->form_validation->set_rules('scategory','category Category', 'required');
			
			
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Category_Sale'));
		}
		else {
		$data = array(
					'created_date' => $this->input->post('created_date'),
					'scategory' => $this->input->post('scategory'),
				
					
				);

		$this->Category_Sales_Model->category_sale_update(array('category_sales_id' => $this->input->post('category_sales_id')), $data);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Category Updated Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
	}

	public function category_sale_delete($id)
	{

		$this->Category_Sales_Model->delete_by_id($id);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Category Deleted Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}



}
