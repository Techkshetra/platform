<div class="content-wrapper">
          <div class="row">
          	 <!--<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                	 <button type="submit" onclick="add_item()" class="btn btn-success">Add New Item</button>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                	 <button type="submit" onclick="add_item()" class="btn btn-success">Add New Item</button>
                	 <br></br>
                  <!--<center><h4 class="card-title">Items</h4></center>-->
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr>
                         
                          <center><th>
                            S.No.</center>
                          </th>
                          <th><center>
                             Item Code</center>
                          </th>
                          <th><center>
                             Category</center>
                          </th>
                          <th><center>
                             Name</center>
                          </th>
                          <th><center>
                             HSN Code No.</center>
                          </th>
                          <th><center>
                             Sales Price</center>
                          </th>
                           <th><center>
                            Purchase Price</center>
                          </th>
                         
                          <th><center>
                            Action</center>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                         <?php $i=sizeof($item_sales); foreach($item_sales as $item_sale){?>

                     <tr>
                        <td><center><?php echo $i--;;?></center></td>
                         <td><center><?php echo $item_sale->item_id;?></center></td>
                          <td><center> <?php foreach($category_sales as $category_sale){if($item_sale->category==$category_sale->category_sales_id) {echo $category_sale->scategory; }}?></center></td>
                          <td><center><?php echo $item_sale->sitemname;?></center></td>
                          
                          <td><center><?php echo $item_sale->hsn_no;?></center></td>
                         <td><center><?php echo $item_sale->sprice;?></center></td>
                          <td><center><?php echo $item_sale->pprice;?></center></td>
                         <!--td><?php echo $item_sale->sper;?></td-->
                                 
                                <td><center>
                                      <button class="btn btn-warning" onclick="edit_item(<?php echo $item_sale->item_sale_id;?>)">Edit</button>
                                    <!--<button class="btn btn-danger" onclick="delete_item(<?php echo $item_sale->item_sale_id;?>)"><i class="fa fa-remove"></i></button>-->
</center>
                                </td>
                      </tr>
                     <?php }?>
                       
                       
                      
                       
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>
        <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;


    function add_item()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_item(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('index.php/Item_Sale/ajax_item_saleedit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="item_sale_id"]').val(data.item_sale_id);
             $('[name="item_id"]').val(data.item_id);
            $('[name="created_date"]').val(data.created_date);
            $('[name="sitemname"]').val(data.sitemname);
             $('[name="hsn_no"]').val(data.hsn_no);
            $('[name="sitemdes"]').val(data.sitemdes);
             $('[name="sprice"]').val(data.sprice);
             $('[name="pprice"]').val(data.pprice);
               $('[name="sper"]').val(data.sper);
                 $('[name="sgst"]').val(data.sgst);
                   $('[name="cgst"]').val(data.cgst);
                    $('[name="igst"]').val(data.igst);
              $('[name="category"]').val(data.category);


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit sale Item'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('index.php/Item_Sale/item_sale_add')?>";
      }
      else
      {
        url = "<?php echo site_url('index.php/Item_Sale/item_sale_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                //alert('Error adding / update data');
                 location.reload();
            }
        });
    }

    function delete_item(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/Item_Sale/item_sale_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

      }
    }

  </script>

<!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        
        <h3 class="modal-title">Add Item</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="item_sale_id"/>
          <input type="date" name="created_date" value="<?php echo date("Y-m-d");?>" hidden />
          <div class="form-body">
            
               <div class="row">
                <div class="col-md-6">
                    
                           <div class="form-group">
                <label class="control-label col-md-3">Category<span style="color: red">*</span></label>
                <div class="col-md-12">
                  <select name="category" class="form-control">
                      <option value="">Select</option>
                      <?php foreach($category_sales as $category_sale){?>
                      <option value="<?php echo $category_sale->category_sales_id;?>"><?php echo $category_sale->scategory;?></option>
                        <?php }?>
                    </select>
                    <!--<input name="category" placeholder="Category" class="form-control" type="text">-->

                </div>
            </div>
                          </div>
                           <div class="col-md-6">
                          <div class="form-group">
              <label class="control-label col-md-12">Item ID<span style="color: red">*</span></label>
              <div class="col-md-12">
                <input name="item_id" placeholder="Item ID" class="form-control" type="text">
              </div>
            </div>
                     </div>
                    

                </div>
                
          
             
            <div class="form-group">
              <label class="control-label col-md-3">Item Name<span style="color: red">*</span></label>
              <div class="col-md-12">
                <input name="sitemname" placeholder="Item Name" class="form-control" type="text">
              </div>
            </div>
           
           
          
               <div class="row">
                <div class="col-md-6">
                    
                          <div class="form-group">
                                <label class="control-label col-md-12">Purchase Price<span style="color: red">*</span></label>
                                 <div class="col-md-12">
                                <input name="pprice" placeholder="Purchase Price" class="form-control" type="text" pattern="[0-9]+">

                             </div>
                          </div>
                          </div>
                           <div class="col-md-6">
                          <div class="form-group">
                                <label class="control-label col-md-12">Sales Price<span style="color: red">*</span></label>
                                    <div class="col-md-12">
                                    <input name="sprice" placeholder="Sales Price" class="form-control" type="text" pattern="[0-9]+">

                                    </div>
                            </div>
                     </div>
                    

                </div>
                
           <div class="row">
                <div class="col-md-6">
                    
                          <div class="form-group">
              <label class="control-label col-md-12">Per Unit.<span style="color: red">*</span></label>
              <div class="col-md-12">
               
                 <select name="sper" class="form-control">
                      <option value="">Select</option>
                      <?php foreach($units as $unit){?>
                      <option value="<?php echo $unit->unitname;?>"><?php echo $unit->unitname;?></option>
                        <?php }?>
                    </select>
              </div>
            </div>
                          </div>
                           <div class="col-md-6">
                           <div class="form-group">
              <label class="control-label col-md-12">HSN Code No.<span style="color: red"></span></label>
              <div class="col-md-12">
                <input name="hsn_no" placeholder="HSN Code No" class="form-control" type="text">
              </div>
            </div>
                     </div>
                    

                </div>
            
            
           
               <div class="row">
                <div class="col-md-4">
                    
                         <div class="form-group">
                <label class="control-label col-md-12">SGST (%)<span style="color: red">*</span></label>
                <div class="col-md-12">
                    <select name="sgst" class="form-control">
                      <option value="">Select</option>
                      <?php foreach($gsts as $gst){?>
                      <option value="<?php echo $gst->value;?>"><?php echo $gst->value;?></option>
                        <?php }?>
                    </select>
                </div>
            </div>
                          </div>
                           <div class="col-md-4">
                          <div class="form-group">
                <label class="control-label col-md-12">CGST (%)<span style="color: red">*</span></label>
                <div class="col-md-12">
                     <select name="cgst" class="form-control">
                      <option value="">Select</option>
                      <?php foreach($gsts as $gst){?>
                      <option value="<?php echo $gst->value;?>"><?php echo $gst->value;?></option>
                        <?php }?>
                    </select>
                </div>
            </div>
                     </div>
                     <div class="col-md-4">
                          <div class="form-group">
                <label class="control-label col-md-12">IGST<span style="color: red"></span></label>
                <div class="col-md-12">
                    <select name="igst" class="form-control">
                      <option value="">Select</option>
                      <?php foreach($gsts as $gst){?>
                      <option value="<?php echo $gst->value;?>"><?php echo $gst->value;?></option>
                        <?php }?>
                    </select>
                </div>
            </div>
                     </div>
                    

                </div>
                
           
             
            
             
            <div class="form-group">
              <label class="control-label col-md-12">Item Description<span style="color: red"></span></label>
              <div class="col-md-12">
                <textarea name="sitemdes"  cols="30" rows="5" placeholder="Item Description" class="form-control"></textarea>
               
              </div>
            </div>
           
            
            

          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->