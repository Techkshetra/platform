<?php  
           $query=$this->db->query("select * from accounts where id=1");
            $result=$query->row_array();
            $company_name=$result['comp_name'];
             $address=$result['comp_add'];
           ?>
<div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper auth-page">
      <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">
        <div class="row w-100">
          <div class="col-lg-12">
              
           <span class="profile-text"><center><h2 style="z-index: 999;color: white"><?php echo "$company_name"; ?></h2></center></span>
            <!--<center><h1 style="z-index: 999;color: white">Billing ERP</h1></center>-->
          </div>
          <div class="col-lg-4 mx-auto">
            <div class="auto-form-wrapper">
              <?php if($this->session->flashdata('message')){ 
                        ?>
                        <div class="alert alert-danger">
                      <?php echo $this->session->flashdata('message'); ?>
                     </div>
                     <?php } ?>
                        <?php echo form_open('Login/login_validation/'); ?>
                <div class="form-group">
                  <label class="label">Email ID</label>
                  <div class="input-group">
                    <input class="form-control" type="text" placeholder="Username" name="username"  autofocus required title="Email required"  AutoComplete=off >
                    <div class="input-group-append">
                      <span class="input-group-text">
                        <i class="mdi mdi-check-circle-outline"></i>
                      </span>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="label">Password</label>
                  <div class="input-group">
                    <input class="form-control" placeholder="Password" name="password" type="password"  required title="Password required" autocomplete=off  value="">
                    <div class="input-group-append">
                      <span class="input-group-text">
                        <i class="mdi mdi-check-circle-outline"></i>
                      </span>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <button class="btn btn-primary submit-btn btn-block">Login</button>
                </div>
              
              </form>
            </div>
           
          
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>














