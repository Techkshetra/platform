 <div class="content-wrapper">
          <div class="row">
             
  <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                     <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                  <center><h4 class="card-title">Profile Setting</h4></center>
                 
        
                  <form class="form-horizontal" role="form" enctype="multipart/form-data" method="post" action="<?php echo base_url() ?>ProfileSettings/update_admin">
                    <div class="form-group">
                         <input type="text" class="form-control" id="exampleInputCity1" placeholder="Location" hidden name="id" value="<?php echo $id;?>">
                      <label for="exampleInputName1">User Name<span style="color: red">*</span></label>
                     
                      <input type="text" class="form-control" id="username" name="username" placeholder="Admin Name" value="<?php echo $username;?>" />
                       <input type="password"  id="exampleInputPassword4" placeholder="Password" name="newpassword" hidden="hidden">
                    </div>
                    <!--<div class="form-group">
                      <label for="exampleInputPassword4">Password</label>
                      <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Password" name="newpassword">
                    </div>-->
                     <div class="form-group">
                      <label for="exampleInputEmail3">Email<span style="color: red">*</span></label>
                      <input type="text" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo $email;?>" />
                     
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail3">Name<span style="color: red">*</span></label>
                      <input type="text" class="form-control" id="comp_name" name="comp_name" placeholder="Company Name" value="<?php echo $comp_name;?>" />
                     
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail3">Address<span style="color: red">*</span></label>
                      <input type="text" class="form-control" id="comp_add" name="comp_add" placeholder="Company Address" value="<?php echo $comp_add;?>" />
                     
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail3">GST No<span style="color: red">*</span></label>
                      <input type="text" class="form-control" id="comp_gst" name="comp_gst" placeholder="Company GST No" value="<?php echo $comp_gst;?>" />
                     
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail3">Terms and Conditions<span style="color: red"></span></label>
                      <textarea" cols="30" rows="5" class="form-control" id="term_cond" name="term_cond" placeholder="Terms and Conditions"><?php echo $term_cond;?></textarea>
                     
                    </div>
                    
                    
                    <div class="form-group">
                      <label>File upload</label>
                     
                      <div class="input-group col-xs-12">
                        <span class="input-group-append">
                           <input type="file" class="form-control file-upload-browse btn btn-info"  placeholder="Upload Image" name="userfile" id="profile_upload" >
                        </span>
                      </div>
                    </div>
                    <!--<div class="form-group">
                      <label for="exampleInputCity1">City</label>
                      <input type="text" class="form-control" id="exampleInputCity1" placeholder="Location">
                    </div>-->
                    <button type="submit" class="btn btn-success mr-2">Update</button>
                    <button class="btn btn-light" >Cancel</button>
                  </form>
                </div>
              </div>
            </div>
          </div>

