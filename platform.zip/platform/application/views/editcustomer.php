<div class="content-wrapper">
          <div class="row">
           
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <center><h4 class="card-title">Edit Customer</h4></center>
                  <form class="form-sample" role="form" action="<?php echo base_url() ?>Customers/customer_update" method="post">
                    <p class="card-description">

                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Date</label>
                          <div class="col-sm-9">
                            <input type="date" class="form-control" value="<?php echo $registration_date;?>" name="registration_date" required="required" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Customer ID</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_id" readonly="readonly" value="<?php echo $customer_id;?>"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Name <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_name" required="required" value="<?php echo $customer_name;?>"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">GST No <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_gst" required="required" value="<?php echo $customer_gst;?>"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Mobile No <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" name="customer_contact" required="required" pattern="[0-9]{10}" value="<?php echo $customer_contact;?>"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Email ID <span style="color: red"></span></label>
                          <div class="col-sm-9">
                            <input class="form-control" type="email" name="customer_email"   value="<?php echo $customer_email;?>"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <p class="card-description">
                      <b>Address</b>
                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Address 1 <span style="color: red"></span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_address1"  value="<?php echo $customer_address1;?>"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Address 2</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_address2"  value="<?php echo $customer_address2;?>"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Postcode <span style="color: red"></span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="postcode" value="<?php echo $postcode;?>"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">City <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="city" required="required"  value="<?php echo $city;?>"/>
                          </div>
                        </div>
                      </div>
                      
                      
                      
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">State <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                           <select name="state"  class="form-control" required="required">
                            <option value="">Select</option>
                              <option <?php if($state=="Andaman and Nicobar Islands"){echo "selected";}?> value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                              <option  <?php if($state=="Andhra Pradesh"){echo "selected";}?> value="Andhra Pradesh">Andhra Pradesh</option>
                              <option  <?php if($state=="Arunachal Pradesh"){echo "selected";}?> value="Arunachal Pradesh">Arunachal Pradesh</option>
                              <option  <?php if($state=="Assam"){echo "selected";}?> value="Assam">Assam</option>
                              <option  <?php if($state=="Bihar"){echo "selected";}?> value="Bihar">Bihar</option>
                              <option  <?php if($state=="Chandigarh"){echo "selected";}?> value="Chandigarh">Chandigarh</option>
                              <option  <?php if($state=="Chhattisgarh"){echo "selected";}?> value="Chhattisgarh">Chhattisgarh</option>
                              <option  <?php if($state=="Dadra and Nagar Haveli"){echo "selected";}?> value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                              <option  <?php if($state=="Daman and Diu"){echo "selected";}?> value="Daman and Diu">Daman and Diu</option>
                              <option  <?php if($state=="Delhi"){echo "selected";}?> value="Delhi">Delhi</option>
                              <option  <?php if($state=="Goa"){echo "selected";}?> value="Goa">Goa</option>
                              <option  <?php if($state=="Gujarat"){echo "selected";}?> value="Gujarat">Gujarat</option>
                              <option  <?php if($state=="Haryana"){echo "selected";}?> value="Haryana">Haryana</option>
                              <option  <?php if($state=="Himachal Pradesh"){echo "selected";}?> value="Himachal Pradesh">Himachal Pradesh</option>
                              <option  <?php if($state=="Jammu and Kashmir"){echo "selected";}?> value="Jammu and Kashmir">Jammu and Kashmir</option>
                              <option  <?php if($state=="Jharkhand"){echo "selected";}?> value="Jharkhand">Jharkhand</option>
                              <option  <?php if($state=="Karnataka"){echo "selected";}?> value="Karnataka">Karnataka</option>
                              <option  <?php if($state=="Kerala"){echo "selected";}?> value="Kerala">Kerala</option>
                              <option  <?php if($state=="Lakshadweep"){echo "selected";}?> value="Lakshadweep">Lakshadweep</option>
                              <option  <?php if($state=="Madhya Pradesh"){echo "selected";}?> value="Madhya Pradesh">Madhya Pradesh</option>
                              <option  <?php if($state=="Maharashtra"){echo "selected";}?> value="Maharashtra">Maharashtra</option>
                              <option  <?php if($state=="Manipur"){echo "selected";}?> value="Manipur">Manipur</option>
                              <option  <?php if($state=="Meghalaya"){echo "selected";}?> value="Meghalaya">Meghalaya</option>
                              <option  <?php if($state=="Mizoram"){echo "selected";}?> value="Mizoram">Mizoram</option>
                              <option  <?php if($state=="Nagaland"){echo "selected";}?> value="Nagaland">Nagaland</option>
                              <option  <?php if($state=="Orissa"){echo "selected";}?> value="Orissa">Orissa</option>
                              <option  <?php if($state=="Pondicherry"){echo "selected";}?> value="Pondicherry">Pondicherry</option>
                              <option  <?php if($state=="Punjab"){echo "selected";}?> value="Punjab">Punjab</option>
                              <option  <?php if($state=="Rajasthan"){echo "selected";}?> value="Rajasthan">Rajasthan</option>
                              <option  <?php if($state=="Sikkim"){echo "selected";}?> value="Sikkim">Sikkim</option>
                              <option  <?php if($state=="Tamil Nadu"){echo "selected";}?> value="Tamil Nadu">Tamil Nadu</option>
                              <option  <?php if($state=="Tripura"){echo "selected";}?> value="Tripura">Tripura</option>
                              <option  <?php if($state=="Uttaranchal"){echo "selected";}?> value="Uttaranchal">Uttaranchal</option>
                              <option  <?php if($state=="Uttar Pradesh"){echo "selected";}?> value="Uttar Pradesh">Uttar Pradesh</option>
                              <option  <?php if($state=="West Bengal"){echo "selected";}?> value="West Bengal">West Bengal</option>
                           </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Country <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <select class="form-control" name="country" required="required">
                              <option  <?php if($country=="India"){echo "selected";}?>  value="India">India</option>
                              <option <?php if($country=="Other"){echo "selected";}?>value="Other">Other</option>
                             
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group row">
                         <center> <input type="submit"  name="submit" value="Submit" class="btn btn-success"/> &nbsp; &nbsp;
                          <input type="reset"  name="submit" value="Clear" class="btn btn-danger"/></center>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>