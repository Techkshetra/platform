<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item_Sale extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Item_Sale_Model');
	 		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	 	}


	public function index()
	{
		$this->load->model('Category_Sales_Model');
		$this->load->model('Gst_Model');
		$this->load->model('Unit_Model');
		$data['category_sales']=$this->Category_Sales_Model->get_all_category_sales();
		$data['item_sales']=$this->Item_Sale_Model->get_all_item_sales();
		$data['units']=$this->Unit_Model->get_active_unit();
		$data['gsts']=$this->Gst_Model->get_active_gst();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('item_sales',$data);
		$this->load->view('footer');
	}
	public function item_sale_add()
		{
			$created_date  = $this->input->post('created_date');
			$sitemname = $this->input->post('sitemname');
			$sprice = $this->input->post('sprice');
			$pprice = $this->input->post('pprice');
			$sgst = $this->input->post('sgst');
			$cgst = $this->input->post('cgst');
			$igst = $this->input->post('igst');
			$category = $this->input->post('category');
		    $item_id = $this->input->post('item_id');
		    $this->form_validation->set_rules('item_id','Item ID', 'required');
			$this->form_validation->set_rules('sitemname','Item Name', 'required');
			$this->form_validation->set_rules('sprice','Sales Price', 'numeric');	
			$this->form_validation->set_rules('pprice','Purchase Price', 'numeric');	
			$this->form_validation->set_rules('cgst','CGST', 'required|numeric');	
			$this->form_validation->set_rules('sgst','SGST', 'required|numeric');	
			$this->form_validation->set_rules('igst','IGST', 'numeric');			
			$this->form_validation->set_rules('category','Item Category', 'required');
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Item_sales'));
		}
		else {
			$data = array(
			    'item_id' => $this->input->post('item_id'),
					'created_date' => $this->input->post('created_date'),
					'sitemname' => $this->input->post('sitemname'),
					'hsn_no' => $this->input->post('hsn_no'),
					'sitemdes' => $this->input->post('sitemdes'),
					'sprice' => $this->input->post('sprice'),
					'pprice' => $this->input->post('pprice'),
					'sper' => $this->input->post('sper'),
					'sgst' => $this->input->post('sgst'),
					'cgst' => $this->input->post('cgst'),
					'igst' => $this->input->post('igst'),
					'category' => $this->input->post('category'),
					
				);
				$insert = $this->Item_Sale_Model->item_sale_add($data);
			
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Item Added Successfully'.'</div>');
				echo json_encode(array("status" => TRUE));
			
		}
			
		}
		public function ajax_item_saleedit($id)
		{
			$data = $this->Item_Sale_Model->get_by_id($id);
			echo json_encode($data);
		}

		public function item_sale_update()
	{
	    
			$created_date  = $this->input->post('created_date');
			$sitemname = $this->input->post('sitemname');
			$sprice = $this->input->post('sprice');
			$pprice = $this->input->post('pprice');
			$sgst = $this->input->post('sgst');
			$cgst = $this->input->post('cgst');
			$igst = $this->input->post('igst');
			$category = $this->input->post('category');	
			$item_id = $this->input->post('item_id');
		    $this->form_validation->set_rules('item_id','Item ID', 'required');
			$this->form_validation->set_rules('sitemname','Item Name', 'required');
			$this->form_validation->set_rules('sprice','Sales Price', 'numeric');	
			$this->form_validation->set_rules('pprice','Purchase Price', 'required|numeric');	
			$this->form_validation->set_rules('cgst','CGST', 'required|numeric');	
			$this->form_validation->set_rules('sgst','SGST', 'required|numeric');	
			$this->form_validation->set_rules('igst','IGST', 'numeric');			
			$this->form_validation->set_rules('category','Item Category', 'required');
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Item_sales'));
		}
		else {
		$data = array(
		    'item_id' => $this->input->post('item_id'),
					'created_date' => $this->input->post('created_date'),
					'sitemname' => $this->input->post('sitemname'),
					'hsn_no' => $this->input->post('hsn_no'),
					'sitemdes' => $this->input->post('sitemdes'),
					'sprice' => $this->input->post('sprice'),
					'pprice' => $this->input->post('pprice'),
					'sper' => $this->input->post('sper'),
					'sgst' => $this->input->post('sgst'),
					'cgst' => $this->input->post('cgst'),
					'igst' => $this->input->post('igst'),
					'category' => $this->input->post('category'),
					
				);

		$this->Item_Sale_Model->item_sale_update(array('item_sale_id' => $this->input->post('item_sale_id')), $data);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Item Updated Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
	}

	public function item_sale_delete($id)
	{

		$this->Item_Sale_Model->delete_by_id($id);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">Item Deleted Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}



}
