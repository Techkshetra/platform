<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GST extends CI_Controller {

	public function __construct() {
		parent::__construct();

		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
		$this->load->model('Gst_Model');
	}
	public function index()
	{
		$data['gsts']=$this->Gst_Model->get_all_gst();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('gst',$data);
		$this->load->view('footer');
	}
	public function gst_add()
		{
			$value  = $this->input->post('value');
			
					
		
			$this->form_validation->set_rules('value','Value', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			echo json_encode(array("status" => TRUE));
		}
		else {
			$data = array(
					'value' => $this->input->post('value'),
					'status' => '1'
					
					
				);
				$insert = $this->Gst_Model->gst_add($data);
			
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">GST Added Successfully'.'</div>');
				echo json_encode(array("status" => TRUE));
			
		}
			
		}
		public function ajax_gstedit($id)
		{
			$data = $this->Gst_Model->get_by_id($id);
			echo json_encode($data);
		}

		public function gst_update()
	{
			$value  = $this->input->post('value');
			
					
		
			$this->form_validation->set_rules('value','Value', 'required');
					
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			echo json_encode(array("status" => TRUE));
		}
		else {
		$data = array(
					'value' => $this->input->post('value'),
					'status' => '1'
					
					
				);

		$this->Gst_Model->gst_update(array('gst_id' => $this->input->post('gst_id')), $data);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">GST Updated Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
	}

	public function gst_delete($id)
	{

		$this->Gst_Model->delete_by_id($id);
		$this->session->set_flashdata('successMessage','<div class="alert alert-success">GST Deleted Successfully'.'</div>');
		echo json_encode(array("status" => TRUE));
	}
public function edit_gststatus($id)
	{
		
		$currentstatus=$this->Gst_Model->get_status_by_id($id);
		if ($currentstatus==1) {
			$newstatus=0;
		}
		else
		{
			$newstatus=1;
		}
		$data = array(
					
					'status' => $newstatus
				);
		$this->Gst_Model->gst_update(array('gst_id' => $id), $data);
		echo json_encode(array("status" => TRUE));
	}


}
