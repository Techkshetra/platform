<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
	}
	public function index()
	{
	//	$this->load->model('Customer_model');
	//	$this->load->model('Purchase_model');
		//$this->load->model('Sales_model');
		//$this->load->model('Stock_model');
		//$data['total_stock']=$this->Stock_model->total_item_stock();
		//$data['total_customers']=$this->Customer_model->no_of_rows();
		//$data['total_purchase_count']=$this->Purchase_model->no_of_rows();
		//$data['total_purchase_amount']=$this->Purchase_model->no_of_rows_total();
		//$data['total_sales_count']=$this->Sales_model->no_of_rows();
		//$data['total_sales_amount']=$this->Sales_model->total_sales_amount();
		//$data['month_sales_count']=$this->Sales_model->no_of_rows_month();
		//$data['month_sales_amount']=$this->Sales_model->month_sales_amount();
		//print_r($data);exit();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('welcome_message');
		$this->load->view('footer');
	}
//	public function all_purchase()
//	{
	//	$this->load->model('Purchase_model');
	//	$this->load->model('Vendor_model');
	//	$data['vendors']=$this->Vendor_model->get_all_vendors();
	//	$data['all_purchases']=$this->Purchase_model->get_all_purchase();
		//print_r($data);exit();
	//	$this->load->view('header');
	//	$this->load->view('navigation');
	//	$this->load->view('all_purchases',$data);
	//	$this->load->view('footer');
	//}
	public function month_sales()
	{
		$this->load->model('Sales_model');
		$data['sales']=$this->Sales_model->get_month_sale();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('sales_counter',$data);
		$this->load->view('footer');
	}
	public function total_sales()
	{
		$this->load->model('Sales_model');
		$data['sales']=$this->Sales_model->get_all_sale();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('sales_counter',$data);
		$this->load->view('footer');
	}
}
