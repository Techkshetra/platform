<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Unit_Model extends CI_Model
{

	var $table = 'unit';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

public function get_all_unit()
{
$this->db->from('unit');
$this->db->order_by('unit_id','DESC');
$query=$this->db->get();
return $query->result();
}

	public function no_of_rows()
	{
		$this->db->select('count(*)');
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['count(*)'];
	}
public function unit_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function unit_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('unit_id', $id);
		$this->db->delete($this->table);
	}
	public function profile_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}
public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('unit_id',$id);
		$query = $this->db->get();
		return $query->row();
	}
	public function get_active_unit()
{
$this->db->from('unit');
$this->db->where('status',1);
$this->db->order_by('unit_id','DESC');
$query=$this->db->get();
return $query->result();
}
public function get_status_by_id($id)
	{
		 $this->db->select('status','status');
		$this->db->where('unit_id', $id);
		$query  = $this->db->get($this->table);
		return $query->row()->status;
	}
}
