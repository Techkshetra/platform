<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customers extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->helper('url');
	 	$this->load->model('Customer_model');
		if (!$this->session->userdata('log_in')) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Login Is Required</div>');
			redirect(base_url('Login'));
		}
		//$this->load->model('Sales_model');
	}
	
	public function index()
	{	
		
		//$data['customer_sales']=$this->Sales_model->customerwise_sales();
		$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('customers',$data);
		//$this->load->view('customers');
		$this->load->view('footer');
	}
	public function customerlist()
	{	
		
		//$data['customer_sales']=$this->Sales_model->customerwise_sales();
		$data['customers']=$this->Customer_model->get_all_customers();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('customerslist',$data);
		//$this->load->view('customers');
		$this->load->view('footer');
	}
	public function adding()

	{	
			$rows = $this->Customer_model->no_of_rows();
			if($rows == 0){
			$customer_id="CI0001";
			}
			else
			{
			$max_id=$this->Customer_model->get_max_id();
			$large_customer_id = $this->Customer_model->get_customer_id($max_id);
			$arr = substr($large_customer_id,2,4);  
			$arr=str_pad($arr + 1, 4, 0, STR_PAD_LEFT);   
			$customer_id="CI".$arr;
			                  
			}
			$data['customer_id']=$customer_id;
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('addcustomers',$data);
		//$this->load->view('addcustomers');
		$this->load->view('footer');
	}
	public function customer_add()
		{
            	$max_id=$this->Customer_model->get_max_id();
            $large_customer_id = $this->Customer_model->get_customer_id($max_id);
			$arr = substr($large_customer_id,2,4);  
			$arr=str_pad($arr + 1, 4, 0, STR_PAD_LEFT);   
			$newcustomer_id="CI".$arr;
			
			if($newcustomer_id==$this->input->post('customer_id')){
			    $customer_id=$this->input->post('customer_id');
			}
			else{
			     $customer_id=$newcustomer_id;
			}
			$customer_name = $this->input->post('customer_name');
			$customer_contact = $this->input->post('customer_contact');
			$this->form_validation->set_rules('customer_name','Customer Name', 'required');
			$this->form_validation->set_rules('customer_contact','Customer Contact', 'required');
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Customers'));
		}
		else {
			$data = array(
				'registration_date' => $this->input->post('registration_date'),
					'customer_id' => $customer_id,
					'customer_name' => $this->input->post('customer_name'),
					'customer_gst' => $this->input->post('customer_gst'),
					'customer_contact' => $this->input->post('customer_contact'),
					'customer_email' => $this->input->post('customer_email'),
					'customer_address1' => $this->input->post('customer_address1'),
					'customer_address2' => $this->input->post('customer_address2'),
					'postcode' => $this->input->post('postcode'),
					'city' => $this->input->post('city'),
					'state' => $this->input->post('state'),
					'country' => $this->input->post('country')	

				);
			if($this->Customer_model->customer_add($data))
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Customer Added Successfully'.'</div>');
				redirect(base_url('Customers'));
				
			}
			else
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Customer cannot be added'.'</div>');
				redirect(base_url('Customers'));
			}
		}
			
		}
		public function edit_customer()
		{
			$id = $this->input->get('customer_id');
			$data= $this->Customer_model->get_by_id($id);
			$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('editcustomer',$data);
		$this->load->view('footer');
		}
		public function customer_update()
		{
			$customer_name = $this->input->post('customer_name');
			$customer_contact = $this->input->post('customer_contact');
			$this->form_validation->set_rules('customer_name','Customer Name', 'required');
			$this->form_validation->set_rules('customer_contact','Customer Contact', 'required');
			if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errorMessage','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Customers'));
		}
		else {
		
			$data = array(
				'registration_date' => $this->input->post('registration_date'),
					'customer_id' => $this->input->post('customer_id'),
					'customer_name' => $this->input->post('customer_name'),
					'customer_gst' => $this->input->post('customer_gst'),
					'customer_contact' => $this->input->post('customer_contact'),
					'customer_email' => $this->input->post('customer_email'),
					'customer_address1' => $this->input->post('customer_address1'),
					'customer_address2' => $this->input->post('customer_address2'),
					'postcode' => $this->input->post('postcode'),
					'city' => $this->input->post('city'),
					'state' => $this->input->post('state'),
					'country' => $this->input->post('country')	

				);
				
			if($this->Customer_model->customer_update(array('customer_id' => $this->input->post('customer_id')), $data))
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Customer Updated Successfully'.'</div>');
				redirect(base_url('Customers'));
				
			}
			else
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Customer cannot be updated'.'</div>');
				redirect(base_url('Customers'));
			}

		}
			
		}
		public function customer_delete()
	{
		
		$id = $this->input->get('customer_id');
		
		if($this->Customer_model->delete_by_id($id))
		{

			$this->session->set_flashdata('successMessage','<div class="alert alert-success">Customer Delted Successfully'.'</div>');
				redirect(base_url('customers'));
				
			}
			else
			{
				$this->session->set_flashdata('successMessage','<div class="alert alert-success">Customer cannot be deleted'.'</div>');
				redirect(base_url('customers'));
			}
	}
public function view_customer()
	{
		$this->load->model('Customer_model');
		$id = $this->input->get('customer_id');
		$data= $this->Customer_model->get_by_id($id);
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('customerview',$data);
		$this->load->view('footer');
	}
			public function purchase_customer()
	{
		$id = $this->input->get('customer_id');
		//print_r($id);exit();
		$data['sales']=$this->Sales_model->get_sales_by_customer_id($id);
		$this->load->model('Customer_model');
		$data['customers']=$this->Customer_model->get_all_customers();
		//print_r($data);exit();
		$this->load->view('header');
		$this->load->view('navigation');
		$this->load->view('customerwise_sales',$data);
		//$this->load->view('purchases');
		$this->load->view('footer');
	}
}