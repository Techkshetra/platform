<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_model extends CI_Model
{

	var $table = 'accounts';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_by_id()
	{
		$this->db->from($this->table);
		$this->db->where('id','1');
		$query = $this->db->get();

		return $query->row();
	}
public function check_old_password()
	{
		$this->load->database();
		$sql = $this->db->where('id','1')
						->get('accounts');
	 	return $row = $sql->row();
	}
	

	public function profile_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	
}
