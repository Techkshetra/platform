<div class="content-wrapper">
          <div class="row">
           
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <center><h4 class="card-title">View Customer</h4></center>
                  <hr>
                    <p class="card-description">

                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Date</label>
                          <div class="col-sm-9">
                            <input type="date" class="form-control" value="<?php echo $registration_date;?>" name="registration_date" required="required" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Customer ID</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_id" readonly="readonly" value="<?php echo $customer_id;?>"/>
                          </div>
                        </div>
                      </div>
                    </div>
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Name <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_name" required="required" value="<?php echo $customer_name;?>" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">GST No <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_gst" required="required" value="<?php echo $customer_gst;?>" readonly/>
                          </div>
                        </div>
                      </div>
                    </div>
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Mobile No <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" name="customer_contact" required="required" pattern="[0-9]{10}" value="<?php echo $customer_contact;?>" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Email ID <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input class="form-control" type="email" name="customer_email" required="required"  value="<?php echo $customer_email;?>" readonly/>
                          </div>
                        </div>
                      </div>
                    </div>
                   <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Address 1 <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_address1" required="required"  value="<?php echo $customer_address1;?>" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Address 2</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="customer_address2"  value="<?php echo $customer_address2;?>" readonly/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Postcode <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="postcode" required="required"  value="<?php echo $postcode;?>" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">City <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="city" required="required"  value="<?php echo $city;?>" readonly/>
                          </div>
                        </div>
                      </div>
                      
                      
                      
                    </div>
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">State <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                           <input type="text" class="form-control" name="state" required="required"  value="<?php echo $state;?>" readonly/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Country <span style="color: red">*</span></label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="country" required="required"  value="<?php echo $country;?>" readonly/>
                          </div>
                        </div>
                      </div>
                    </div>
                
                </div>
              </div>
            </div>
          </div>
        </div>