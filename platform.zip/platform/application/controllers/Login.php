<?php 
class Login extends CI_Controller {

	public function index() {
		$data['page_name'] = "Login";
		$this->load->view('header',$data);
		$this->load->view('login');
$this->load->view('footer');
		
	}

	public function login_validation() {
	  
	    if($this->input->get('username')){
	   $username = $this->input->get('username');
		$password = $this->input->get('password');
	    }
	    else
	   {
		$username = $this->input->post('username');
		$password = $this->input->post('password');
	    }
	     //print_r($password);exit();
	/*	$this->form_validation->set_rules('username','Username', 'required');
		$this->form_validation->set_rules('password','Password', 'required');
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('message','<div class="alert alert-danger">' . validation_errors() . '</div>');
			redirect(base_url('Login'));
		}else {*/
			$this->load->model('accounts_model');
			$verify_login = $this->accounts_model->login($username);
			if ($verify_login) {
				$hash_password = $verify_login->password;
				$hash = password_verify($password,$hash_password);
				if ($hash) {
					$userdata = array( 
						'id' => "$verify_login->id",
						'username' => "$verify_login->username",
						'log_in' => true,
						);
					$this->session->set_userdata($userdata);
					$this->session->set_flashdata('message','<div class="alert alert-success">Login Successfully, Welcome '.$this->session->userdata['username'].'</div>');
					
						redirect(base_url('Welcome'));
					
				}else {
					$this->session->set_flashdata('message','<div class="alert alert-danger">Incorrect Login Name Or Password</div>');
				redirect(base_url('Login'));
				}
			}else {
				$this->session->set_flashdata('message','<div class="alert alert-danger">Incorrect Login Name Or Password</div>');
				redirect(base_url('Login'));
			}
		
	}
  public function forgotPassword() {
$this->load->helper('string', 6);
$newpassword= random_string('alnum', 12);
$encrypt_password = password_hash($newpassword,PASSWORD_DEFAULT);
$data = array(			
					'password' => $encrypt_password);
$this->load->model('accounts_model');
$this->accounts_model->forgetpass_update(array('id' => 1), $data );
$toemail=$this->accounts_model->get_email_by_id();

echo $newpassword;
//Load email library
$this->load->library('email');

//SMTP & mail configuration
$config = array(
    'protocol'  => 'smtp',
    'smtp_host' => 'ssl://mail.site.com',
    'smtp_port' => 465,
    'smtp_user' => 'your mail id',
    'smtp_pass' => 'your password',
    'mailtype'  => 'html',
    'charset'   => 'utf-8'
);
$this->email->initialize($config);
$this->email->set_mailtype("html");
$this->email->set_newline("\r\n");

//Email content
$htmlContent = '<h1>Your Password For Techinva Admin Login is set as</h1>';
$htmlContent .= $newpassword;

$this->email->to($toemail);
$this->email->from('your mail id','Techinva');
$this->email->subject('New Pass For Techinva');
$this->email->message($htmlContent);




          if($this->email->send()){
                
                    $this->session->set_flashdata('message','<div class="alert alert-success">New Password has been send to registered Email ID</div>');
				redirect(base_url('Login'));
                
            }
            else{

show_error($this->email->print_debugger()); 

/* $this->session->set_flashdata('errorMessage','<div class="alert alert-danger">Mail Was not send to registered mail id. Contact your administrator.</div>');
				redirect(base_url('Login'));*/
            }
	}
}

?>