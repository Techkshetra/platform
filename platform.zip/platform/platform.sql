-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2018 at 12:58 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comp_name` varchar(255) NOT NULL,
  `comp_add` varchar(255) NOT NULL,
  `comp_gst` varchar(255) NOT NULL,
  `term_cond` varchar(700) NOT NULL,
  `admin_photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `email`, `comp_name`, `comp_add`, `comp_gst`, `term_cond`, `admin_photo`) VALUES
(1, 'admin', '$2y$10$Mr4eS8U9U7vvFHRGIGZb5ujWEEykVUqLFKndX8BaPm57BTduYyKT6', 'info@yourdomain.com', 'Demo', 'Location', 'GST12343', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `registration_date` date NOT NULL,
  `customer_id` varchar(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_gst` varchar(100) NOT NULL,
  `customer_contact` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_address1` varchar(500) NOT NULL,
  `customer_address2` varchar(500) NOT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `city` varchar(300) NOT NULL,
  `state` varchar(110) DEFAULT NULL,
  `country` varchar(110) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `registration_date`, `customer_id`, `customer_name`, `customer_gst`, `customer_contact`, `customer_email`, `customer_address1`, `customer_address2`, `postcode`, `city`, `state`, `country`) VALUES
(1, '2018-11-06', 'CI0001', 'Techkshetra', 'gst3456', '8909871234', 'ushna.cse@gmail.com', 'test', 'test', '585103', 'kalaburagi', 'Karnataka', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `gst`
--

CREATE TABLE `gst` (
  `gst_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gst`
--

INSERT INTO `gst` (`gst_id`, `value`, `status`) VALUES
(1, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `saleitems`
--

CREATE TABLE `saleitems` (
  `item_sale_id` int(11) NOT NULL,
  `item_id` varchar(255) NOT NULL,
  `created_date` date NOT NULL,
  `sitemname` varchar(255) NOT NULL,
  `hsn_no` varchar(100) NOT NULL,
  `sitemdes` varchar(255) NOT NULL,
  `sprice` float NOT NULL DEFAULT '0',
  `pprice` float NOT NULL DEFAULT '0',
  `sper` varchar(100) NOT NULL,
  `sgst` int(11) NOT NULL,
  `cgst` int(11) NOT NULL,
  `igst` varchar(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `opening_stock` int(11) NOT NULL,
  `current_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saleitems`
--

INSERT INTO `saleitems` (`item_sale_id`, `item_id`, `created_date`, `sitemname`, `hsn_no`, `sitemdes`, `sprice`, `pprice`, `sper`, `sgst`, `cgst`, `igst`, `category`, `opening_stock`, `current_stock`) VALUES
(1, 'IT001', '2018-11-06', 'Itemtestnew', '', 'Description of item', 14, 12, 'per', 9, 9, '9', '1', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `salescategory`
--

CREATE TABLE `salescategory` (
  `category_sales_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `scategory` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salescategory`
--

INSERT INTO `salescategory` (`category_sales_id`, `created_date`, `scategory`) VALUES
(1, '2018-11-06', 'item12');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL,
  `unitname` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unit_id`, `unitname`, `status`) VALUES
(1, 'per', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`,`customer_id`),
  ADD UNIQUE KEY `customer_id` (`customer_id`);

--
-- Indexes for table `gst`
--
ALTER TABLE `gst`
  ADD PRIMARY KEY (`gst_id`);

--
-- Indexes for table `saleitems`
--
ALTER TABLE `saleitems`
  ADD PRIMARY KEY (`item_sale_id`);

--
-- Indexes for table `salescategory`
--
ALTER TABLE `salescategory`
  ADD PRIMARY KEY (`category_sales_id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`unit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `gst`
--
ALTER TABLE `gst`
  MODIFY `gst_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `saleitems`
--
ALTER TABLE `saleitems`
  MODIFY `item_sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `salescategory`
--
ALTER TABLE `salescategory`
  MODIFY `category_sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
