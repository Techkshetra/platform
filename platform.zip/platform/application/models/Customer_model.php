<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_model extends CI_Model
{

	var $table = 'customers';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


public function get_all_customers()
{
$this->db->from('customers');
$this->db->order_by('id','DESC');
$query=$this->db->get();
return $query->result();
}


	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('customer_id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function customer_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function customer_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('customer_id', $id);
		$this->db->delete($this->table);
	}

public function no_of_rows()
	{
		$this->db->select('count(*)');
		$query = $this->db->get($this->table);
		$cnt = $query->row_array();
		return $cnt['count(*)'];
	}
	public function get_customer_id($id) {     
         $this->db->select('customer_id','customer_id');
		$this->db->where('id', $id);
		$query  = $this->db->get($this->table);
		return $query->row()->customer_id;
	}
	public function get_max_id() {     
         $this->db->select_max('id','id');
		$result = $this->db->get($this->table);  
		return $result->row()->id;
	}

}
