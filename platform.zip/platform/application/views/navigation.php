<style>
  .sidebar .nav .nav-item .nav-link .menu-title,.sidebar .nav .nav-item .nav-link .menu-icon {

    color: #000;
    display: inline-block;
    font-size: 14.5px;
    line-height: 1;
    vertical-align: middle;

}

</style>
<?php  
           $query=$this->db->query("select * from accounts where id=1");
            $result=$query->row_array();
            $company_name=$result['comp_name'];
             $address=$result['comp_add'];
           ?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
       <a class="navbar-brand brand-logo" href="<?php echo base_url(); ?>Welcome">
          <img src="<?php echo base_url(); ?>assets/images/faces/face1.jpg" alt="logo" />
        </a>
        <a class="navbar-brand brand-logo-mini" href="<?php echo base_url(); ?>Welcome">
          <img src="<?php echo base_url(); ?>assets/images/faces/face1.jpg" alt="logo" />
        </a>
      </div>
      
      <div class="navbar-menu-wrapper d-flex align-items-center">
           <span class="profile-text"><center><?php echo "$company_name"; ?></center></span>
        
        <ul class="navbar-nav navbar-nav-right">
          
          
          <li class="nav-item dropdown d-none d-xl-inline-block">
             
            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                
              <span class="profile-text">You are logged in as : Admin</span>
              <img class="img-xs rounded-circle" src="<?php echo base_url(); ?>assets/images/faces/face1old.jpg" alt="Profile image">
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
             
             
              <a class="dropdown-item" href="<?php echo base_url(); ?>ProfileSettings">
                Profile Setting
              </a>
              <br>
               <a class="dropdown-item" href="<?php echo base_url(); ?>ProfileSettings/change_password">
                Change Password
              </a>
              <br>
              <a class="dropdown-item" href="<?php echo base_url(); ?>Logout">
                Logout
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <br>
        <ul class="nav">
        <!-- <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="<?php echo base_url(); ?>assets/images/faces/face1.jpg" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name">Billing ERP</p>
                  <div>
                    <small class="designation text-muted">Admin</small>
                    <span class="status-indicator online"></span>
                  </div>
                </div>
              </div>
            
            </div>
          </li>-->
        
          <li class="nav-item">
            <a class="nav-link <?php if($this->uri->uri_string() == "" || $this->uri->uri_string() == "Welcome") { echo 'active'; } ?>" href="<?php echo base_url(); ?>Welcome">
              <i class="menu-icon mdi mdi-television"></i>
              <span class="menu-title">Dashboard</span>
               
            </a>
           
          </li>
   
          <!--<li class="nav-item">
            <a class="nav-link <?php if($this->uri->uri_string() == "Purchase" || $this->uri->uri_string() == "Purchase/addpurchase") { echo 'nav-link'; } ?>" href="<?php echo base_url(); ?>Purchase">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Purchase/Prod.</span>
            </a>
          </li>-->
          
          
          <li class="nav-item">
            <a class="nav-link <?php if($this->uri->uri_string() == "Customers" || $this->uri->uri_string() == "Customers/addcustomer") { echo 'nav-link'; } ?>" href="<?php echo base_url(); ?>Customers">
              <i class="menu-icon mdi mdi-account"></i>
              <span class="menu-title">Customers</span>
            </a>
          </li>
         
         <!--<li class="nav-item">
            <a class="nav-link <?php if($this->uri->uri_string() == "Purchase" || $this->uri->uri_string() == "Purchase/addpurchase") { echo 'nav-link'; } ?>" href="<?php echo base_url(); ?>Purchase">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">RM Purchase</span>
            </a>
          </li>-->
          
         
          <!--<li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>assets/pages/icons/font-awesome.html">
              <i class="menu-icon mdi mdi-sticker"></i>
              <span class="menu-title">Reports</span>
            </a>
          </li>-->
          
          <!--<li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
              <i class="menu-icon mdi mdi-restart"></i>
              <span class="menu-title">Reports</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="auth">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>Reports/purchase_report">Purchase</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>Reports/sales_report">Sales </a>
                </li>
               <!-- <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>"> Customer </a>
                </li>-->
             <!-- </ul>
            </div>
          </li>-->
           <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>Settings">
              <i class="menu-icon mdi mdi-sticker"></i>
              <span class="menu-title">Settings
            </span>
            </a>
          </li>
        </ul>
      </nav>
      <div class="main-panel">