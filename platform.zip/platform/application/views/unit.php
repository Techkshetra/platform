<div class="content-wrapper">
          <div class="row">
          	 <!--<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                   <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                	 <button type="submit" onclick="add_unit()" class="btn btn-success">Add New unit</button>
                </div>
              </div>
            </div>-->
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <?php echo $this->session->flashdata('errorMessage') ?>
                      <?php echo $this->session->flashdata('successMessage') ?>
                	 <button type="submit" onclick="add_unit()" class="btn btn-success">Add New unit</button>
                	 <br></br>
                  <!--<center><h4 class="card-title">unit</h4></center>-->
                  
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th><center>
                            S.No</center>
                          </th>
                          
                          <th><center>
                             Unit &nbsp;Id</center>
                          </th>
                          <th><center>
                             Unit &nbsp;Name</center>
                          </th>
                     <th><center>
                            Status</center>
                          </th>
                           
                          <!--<th width="150px">
                            Action
                          </th>-->
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                         <?php $i=sizeof($units); foreach($units as $unit){?>

                     <tr>
                        <td><center><?php echo $i--;;?></center></td>
                         <td><center><?php echo $unit->unit_id;?></center></td>
                          <td><center><?php echo $unit->unitname;?></center></td>
                        
                                 <td><center>
                            <button 
                             class="btn btn-<?php if($unit->status=="1"){echo "success";}else{echo "danger";}?>" 
                                onclick="edit_unitstatus(<?php echo $unit->unit_id;?>)" data-toggle="tooltip" 
                                title="<?php if($unit->status=="1"){echo "Inactivate";}else{echo "Activate";}?>">
                                 <?php if($unit->status=="1"){echo "Active";}else{echo "Inactive";}?>
                             </button></center></td> 
                                <!--<td>
                                      <button class="btn btn-warning" onclick="edit_unit(<?php echo $unit->unit_id;?>)">Edit</button>
                                    <!--<button class="btn btn-danger" onclick="delete_unit(<?php echo $unit->unit_id;?>)"><i class="fa fa-remove"></i></button>

                                </td>-->
                      </tr>
                     <?php }?>
                       
                       
                      
                       
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
          </div>
        </div>
        <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;


    function add_unit()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_unit(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('index.php/unit/ajax_unitedit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="unit_id"]').val(data.unit_id);
          
            $('[name="unitname"]').val(data.unitname);
         


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Unit'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('index.php/Unit/unit_add')?>";
      }
      else
      {
        url = "<?php echo site_url('index.php/Unit/unit_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                //alert('Error adding / update data(' + errorThrown+')');
                location.reload();
            }
        });
    }

    function delete_unit(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/Unit/unit_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

      }
    }
function edit_unitstatus(id)
    {
      if(confirm('Are you sure want to update the status'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/Unit/edit_unitstatus')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Cannot update the unit Status');
            }
        });

      }
    }
  </script>

<!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        
        <h3 class="modal-title">Add Unit</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="unit_id"/>
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-12">Unit Name<span style="color: red">*</span></label>
              <div class="col-md-12">
                <input name="unitname" placeholder="Unit Name" class="form-control" type="text">
              </div>
            </div>
           
        

          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->